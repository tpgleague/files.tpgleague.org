dod_rails, originally dod_railroad2 for DoD, created by insta.
brought to source for use in league gaming with permission from Insta.